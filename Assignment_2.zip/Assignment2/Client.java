import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.*;
import java.net.Socket;
import java.net.UnknownHostException;
import java.util.Scanner;

public class Client {
    public static String computerName = null;
    public static File clientDirectory = null;

    private Socket socket = null;

    private PrintWriter networkOut = null;
    private BufferedReader networkIn = null;

    public static String SERVER_ADDRESS = "localhost";
    public static int SERVER_PORT = 16789;

    public Client() {
        try {
            socket = new Socket(SERVER_ADDRESS, SERVER_PORT);
        } catch (UnknownHostException e) {
            System.err.println("Unknown host: " + SERVER_ADDRESS);
        } catch (IOException e) {
            System.err.println("IOException while connecting to server: " + SERVER_ADDRESS);
        }
        if (socket == null) {
            System.err.println("socket is null");
        }
        try {
            networkOut = new PrintWriter(socket.getOutputStream(), true);
            networkIn = new BufferedReader(new InputStreamReader(socket.getInputStream()));
        } catch (IOException e) {
            System.err.println("IOException while opening a read/write connection");
        }
	
        processUserInput();

        try {
            socket.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    protected void processUserInput() {
        JFrame jFrame = new JFrame("Client Server");
        jFrame.setSize(400, 400);
        jFrame.setLayout(new BoxLayout(jFrame.getContentPane(), BoxLayout.Y_AXIS));
        jFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        JPanel jPanel = new JPanel();
        jPanel.setLayout(new BoxLayout(jPanel, BoxLayout.Y_AXIS));

        JLabel title = new JLabel(computerName + "'s Computer");
        title.setAlignmentX(Component.CENTER_ALIGNMENT);
        title.setBorder(new EmptyBorder(20,0,10,0));
        title.setFont(new Font("Arial", Font.BOLD, 25));

        JButton serverDir = new JButton("SERVER DIR");
        serverDir.setPreferredSize(new Dimension(150, 75));
        serverDir.setFont(new Font("Arial", Font.BOLD, 15));

        JButton clientDir = new JButton("MY DIR");
        clientDir.setPreferredSize(new Dimension(150, 75));
        clientDir.setFont(new Font("Arial", Font.BOLD, 15));

        JButton upload = new JButton("UPLOAD");
        upload.setPreferredSize(new Dimension(150, 75));
        upload.setFont(new Font("Arial", Font.BOLD, 15));

        JButton download = new JButton("DOWNLOAD");
        download.setPreferredSize(new Dimension(150, 75));
        download.setFont(new Font("Arial", Font.BOLD, 15));

        JPanel buttons = new JPanel();
        buttons.add(serverDir);
        buttons.add(clientDir);
        buttons.add(upload);
        buttons.add(download);
        buttons.setBorder(new EmptyBorder(50, 0, 10, 0));

        serverDir.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                displayServerDir();
            }
        });

        clientDir.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                displayClientDir();
            }
        });

        upload.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String fileName = selectClientFile();
                File file = new File(clientDirectory + "\\" + fileName);
                sendFile(file, fileName);
            }
        });
/*
        download.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String fileName = selectServerFile();
                receiveFile(clientDirectory + "\\" + fileName);
            }
        });*/

        jPanel.add(title);
        jPanel.add(buttons);
        jFrame.add(jPanel);
	jFrame.setVisible(true);
    }

    public void displayServerDir() {
        int size = 0;
        String fileName = null;

        networkOut.println("DIR");
        try {
            size = Integer.valueOf(networkIn.readLine());
        } catch (IOException ex) {
            ex.printStackTrace();
        }

        String[] columns = new String[] { "Server Files" };
        Object[][] data = new Object[size][1];

        for (int i = 0; i < size; i ++) {
            try {
                fileName = networkIn.readLine();
            } catch (IOException ex) {
                ex.printStackTrace();
            }
            data[i][0] = fileName;
        }

        JTable table = new JTable(data, columns);
        JScrollPane jScrollPane = new JScrollPane(table);

        JFrame jFrame = new JFrame("Server Directory");
        jFrame.setSize(400, 400);
        jFrame.setLayout(new BoxLayout(jFrame.getContentPane(), BoxLayout.Y_AXIS));
        jFrame.add(jScrollPane);
        jFrame.setVisible(true);
    }

    public void displayClientDir() {
        String textFiles[] = clientDirectory.list();
        int size = textFiles.length;
        String fileName = null;

        String[] columns = new String[] { "My Files" };
        Object[][] data = new Object[size][1];

        for (int i = 0; i < size; i ++) { data[i][0] = textFiles[i]; }

        JTable table = new JTable(data, columns);
        JScrollPane jScrollPane = new JScrollPane(table);

        JFrame jFrame = new JFrame("My Directory");
        jFrame.setSize(400, 400);
        jFrame.setLayout(new BoxLayout(jFrame.getContentPane(), BoxLayout.Y_AXIS));
        jFrame.add(jScrollPane);
        jFrame.setVisible(true);
    }

    public String selectClientFile() {
        String textFiles[] = clientDirectory.list();
        int size = textFiles.length;
        String fileName = null;

        String[] columns = new String[] { "My Files" };
        Object[][] data = new Object[size][1];

        for (int i = 0; i < size; i ++) { data[i][0] = textFiles[i]; }

        JTable table = new JTable(data, columns);

        table.setRowSelectionAllowed(true);
        int column = 0;
        int row = table.getSelectedRow();
        String value = table.getModel().getValueAt(row, column).toString();

        JScrollPane jScrollPane = new JScrollPane(table);

        JFrame jFrame = new JFrame("My Directory");
        jFrame.setSize(400, 400);
        jFrame.setLayout(new BoxLayout(jFrame.getContentPane(), BoxLayout.Y_AXIS));
        jFrame.add(jScrollPane);
        jFrame.setVisible(true);

        return value;
    }

    public void sendFile(File file, String fileName) {
        networkOut.println("UPLOAD");
        try {
            Scanner sc = new Scanner(file);
            FileReader fr = new FileReader(file);
            BufferedReader br = new BufferedReader(fr);

            String line;
            int count = 0;

            while(sc.hasNextLine()) {
                sc.nextLine();
                count++;
            }

            networkOut.println(fileName);
            networkOut.println(count);

            while ((line = br.readLine()) != null) {
                networkOut.println(line);
            }
            sc.close();
            br.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public static void main(String[] args) {
        if (args.length == 0 || args.length == 1) {
            System.out.println("Usage: java FileSharingServer <computer name> <directory>");
            return;
        }

        computerName = (args[0]);
        clientDirectory = new File(args[1]);

        if (!clientDirectory.exists()) {
            System.out.println("Specified directory does not exist.");
            return;
        }
        if (!clientDirectory.isDirectory()) {
            System.out.println("The specified file is not a directory.");
            return;
        }

        Client client = new Client();
    }
}
