import java.io.*;
import java.net.ServerSocket;
import java.net.Socket;

public class Server {
    // Server's file directory
    public static File serverDirectory = new File(".\\files");

    protected Socket clientConnection = null;
    protected ServerSocket listener = null;

    protected BufferedReader in = null;
    protected PrintWriter out = null;

    protected int numClients = 0;

    public static int SERVER_PORT = 16789;

    public Server() {
        try {
            listener = new ServerSocket(SERVER_PORT);

            System.out.println("---------------------------");
            System.out.println("File Sharing Server Application is running");
            System.out.println("---------------------------");
            System.out.println("Listening to port: " + SERVER_PORT);

            // Server accepts multiple clients, fulfills one request per client, and then disconnects
            // the connection
            while(true) {
                clientConnection = listener.accept();
                System.out.println("Client #"+ (numClients + 1) + " connected.");
                numClients = numClients + 1;

                out = new PrintWriter(clientConnection.getOutputStream(), true);
                in = new BufferedReader(new InputStreamReader(clientConnection.getInputStream()));

                String command = null;
                String textFiles[] = serverDirectory.list();

                command = in.readLine();

                if (command.equals("DIR")) {
                    // When user clicks on "DIR" button in UI, server returns the file names
                    // in the shared folder on the server.
                    out.println(textFiles.length);
                    for (int i = 0; i < textFiles.length; i ++) {
                        out.println(textFiles[i]);
                    }
                }
                else if (command.equals("UPLOAD")) {
                    // When user clicks on "UPLOAD" button in UI, server creates a file that it
                    // will read the text file content into.
                    String fileName = in.readLine();
                    int numLines = Integer.valueOf(in.readLine());
                    File file = new File(serverDirectory + "\\" + fileName);

                    // Calls method to write the content into a file that will be stored onto the
                    // the server's file directory.
                    receiveFile(file, numLines);
                } /*
                else if (command.equals("DOWNLOAD")) {
                    String fileName = in.readLine();

                } */

                in.close();
                out.close();
                //clientConnection.close();
            }
        } catch (IOException e) {
            System.err.println("IOException while creating server connection");
        }
    }

    public void receiveFile(File file, int numLines) {
        try {
            FileWriter writer = new FileWriter(file);
            String line;

            for (int i = 0; i < numLines; i ++) {
                line = in.readLine();
                writer.write(line);
            }
            writer.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public static void main(String[] args) {
        Server app = new Server();
    }
}
